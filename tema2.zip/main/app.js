var Validator = require('validate-params');

function addTokens(input, tokens){
    //TEST1
    if(typeof input==="string"){
        console.log("Input is a string")
    }
    else{
        throw TypeError("Invalid input");
    }


    //TEST2
    if(input.length<6){
        throw TypeError("Input should have at least 6 characters");
    }


    //TEST3
    //Validator.assert.arg(tokens, [{tokenName: "string"}]);
    if(Array.isArray(tokens))
    {
        tokens.forEach((elem)=>
        {
            if(typeof elem.tokenName!="string")
            {
                throw new Error("Invalid array format")
            }
        })
    }


    //TEST4
    var dots="..."
    if(!(input.includes(dots))) {
        return input
    }

    //TEST5
    else{
        var newinput
        tokens.forEach((elem)=>
           newinput=input.replace(dots, "${" + elem.tokenName + "}")
        )
        return newinput;
    }
}

const app = {
    addTokens: addTokens
}

module.exports = app;